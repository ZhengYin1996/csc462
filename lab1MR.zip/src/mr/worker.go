package mr

//Eventually, there will be more here! :) 

//
// Map functions return a slice of KeyValue.
//

type KeyValue struct {
	Key   string
	Value string
}

